package org.lflang.analyses.maude;

public class MaudeTypes {

    public enum MaudeVarType {
        RVarId,
        BVarId,
    }

    public enum MaudePortType {
        RPortId,
        BPortId,
    }

    public enum MaudeActionType {
        RActionId,
        BActionId,
    }
}
