#!/bin/bash
echo "Hello from pre-build script!"
export FOO=foo
