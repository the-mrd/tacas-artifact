#!/bin/bash
echo "Hello from post-build script!"
