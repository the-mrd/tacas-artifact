#!/bin/bash
echo "Hello from pre-build script with a foolish name!"
