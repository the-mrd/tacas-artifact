#!/bin/bash
echo "Hello from pre-run script!"
export BAR=bar
