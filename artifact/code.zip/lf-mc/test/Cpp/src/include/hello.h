#ifndef HELLO_H
#define HELLO_H

struct Hello {
    std::string name;
    int value;
 };

#endif
